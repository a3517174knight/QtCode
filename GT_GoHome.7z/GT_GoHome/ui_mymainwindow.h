/********************************************************************************
** Form generated from reading UI file 'mymainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYMAINWINDOW_H
#define UI_MYMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <mylabel.h>

QT_BEGIN_NAMESPACE

class Ui_MyMainWindow
{
public:
    QAction *action_Reset;
    QWidget *centralWidget;
    MyLabel *label_16;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_2;
    QLabel *label_Url;
    QGridLayout *gridLayout_11;
    QLabel *label;
    QComboBox *CBM_axis;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_2;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *Edit_velHigh;
    QLineEdit *Edit_velLow;
    QLineEdit *Edit_acc;
    QLineEdit *Edit_dec;
    QLineEdit *Edit_smoothTime;
    QLineEdit *Edit_homeOffset;
    QLineEdit *Edit_searchHomeDistance;
    QLineEdit *Edit_searchIndexDistance;
    QLineEdit *Edit_escapeStep;
    QVBoxLayout *verticalLayout_4;
    QComboBox *comboBox_TRRIGER;
    QHBoxLayout *horizontalLayout_3;
    QCheckBox *checkBox_IndexP;
    QCheckBox *checkBox_IndexN;
    QHBoxLayout *horizontalLayout_2;
    QCheckBox *checkBox_StartN;
    QCheckBox *checkBox_StartP;
    QHBoxLayout *horizontalLayout_4;
    QCheckBox *checkBox_CaptchP;
    QCheckBox *checkBox_CaptchN;
    QComboBox *comboBox_2;
    QSpacerItem *horizontalSpacer;
    QGridLayout *gridLayout_5;
    QPushButton *PushButtonInit;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_Enable;
    QPushButton *pushButton_12;
    QGridLayout *gridLayout;
    QLabel *label_pixMap;
    QLabel *label_movie;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_10;
    QGridLayout *gridLayout_8;
    QLabel *label_17;
    QLabel *label_19;
    QLabel *label_26;
    QLabel *label_27;
    QLabel *label_29;
    QGridLayout *gridLayout_9;
    QLabel *label_Sts;
    QLabel *label_Stage;
    QLabel *label_Error;
    QLabel *label_23;
    QLabel *label_28;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MyMainWindow)
    {
        if (MyMainWindow->objectName().isEmpty())
            MyMainWindow->setObjectName(QStringLiteral("MyMainWindow"));
        MyMainWindow->resize(981, 677);
        MyMainWindow->setMinimumSize(QSize(200, 200));
        action_Reset = new QAction(MyMainWindow);
        action_Reset->setObjectName(QStringLiteral("action_Reset"));
        centralWidget = new QWidget(MyMainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label_16 = new MyLabel(centralWidget);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(290, 570, 551, 41));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(12, 12, 837, 561));
        gridLayout_2 = new QGridLayout(layoutWidget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        label_Url = new QLabel(layoutWidget);
        label_Url->setObjectName(QStringLiteral("label_Url"));

        gridLayout_2->addWidget(label_Url, 0, 0, 1, 1);

        gridLayout_11 = new QGridLayout();
        gridLayout_11->setSpacing(6);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout_11->addWidget(label, 0, 0, 1, 1);

        CBM_axis = new QComboBox(layoutWidget);
        CBM_axis->setObjectName(QStringLiteral("CBM_axis"));

        gridLayout_11->addWidget(CBM_axis, 0, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout_11, 1, 0, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout_3->addWidget(label_2);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout_3->addWidget(label_4);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout_3->addWidget(label_5);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        verticalLayout_3->addWidget(label_6);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout_3->addWidget(label_3);


        gridLayout_2->addLayout(verticalLayout_3, 2, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setMinimumSize(QSize(20, 20));

        verticalLayout->addWidget(label_7);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setMinimumSize(QSize(20, 20));

        verticalLayout->addWidget(label_8);

        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setMinimumSize(QSize(20, 20));

        verticalLayout->addWidget(label_9);

        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QStringLiteral("label_10"));

        verticalLayout->addWidget(label_10);

        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName(QStringLiteral("label_11"));

        verticalLayout->addWidget(label_11);

        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName(QStringLiteral("label_12"));

        verticalLayout->addWidget(label_12);

        label_13 = new QLabel(layoutWidget);
        label_13->setObjectName(QStringLiteral("label_13"));

        verticalLayout->addWidget(label_13);

        label_14 = new QLabel(layoutWidget);
        label_14->setObjectName(QStringLiteral("label_14"));

        verticalLayout->addWidget(label_14);

        label_15 = new QLabel(layoutWidget);
        label_15->setObjectName(QStringLiteral("label_15"));

        verticalLayout->addWidget(label_15);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        Edit_velHigh = new QLineEdit(layoutWidget);
        Edit_velHigh->setObjectName(QStringLiteral("Edit_velHigh"));
        Edit_velHigh->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_velHigh);

        Edit_velLow = new QLineEdit(layoutWidget);
        Edit_velLow->setObjectName(QStringLiteral("Edit_velLow"));
        Edit_velLow->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_velLow);

        Edit_acc = new QLineEdit(layoutWidget);
        Edit_acc->setObjectName(QStringLiteral("Edit_acc"));
        Edit_acc->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_acc);

        Edit_dec = new QLineEdit(layoutWidget);
        Edit_dec->setObjectName(QStringLiteral("Edit_dec"));
        Edit_dec->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_dec);

        Edit_smoothTime = new QLineEdit(layoutWidget);
        Edit_smoothTime->setObjectName(QStringLiteral("Edit_smoothTime"));
        Edit_smoothTime->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_smoothTime);

        Edit_homeOffset = new QLineEdit(layoutWidget);
        Edit_homeOffset->setObjectName(QStringLiteral("Edit_homeOffset"));
        Edit_homeOffset->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_homeOffset);

        Edit_searchHomeDistance = new QLineEdit(layoutWidget);
        Edit_searchHomeDistance->setObjectName(QStringLiteral("Edit_searchHomeDistance"));
        Edit_searchHomeDistance->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_searchHomeDistance);

        Edit_searchIndexDistance = new QLineEdit(layoutWidget);
        Edit_searchIndexDistance->setObjectName(QStringLiteral("Edit_searchIndexDistance"));
        Edit_searchIndexDistance->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_searchIndexDistance);

        Edit_escapeStep = new QLineEdit(layoutWidget);
        Edit_escapeStep->setObjectName(QStringLiteral("Edit_escapeStep"));
        Edit_escapeStep->setMinimumSize(QSize(50, 20));

        verticalLayout_2->addWidget(Edit_escapeStep);


        horizontalLayout->addLayout(verticalLayout_2);


        gridLayout_2->addLayout(horizontalLayout, 3, 0, 1, 2);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        comboBox_TRRIGER = new QComboBox(layoutWidget);
        comboBox_TRRIGER->setObjectName(QStringLiteral("comboBox_TRRIGER"));

        verticalLayout_4->addWidget(comboBox_TRRIGER);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        checkBox_IndexP = new QCheckBox(layoutWidget);
        checkBox_IndexP->setObjectName(QStringLiteral("checkBox_IndexP"));

        horizontalLayout_3->addWidget(checkBox_IndexP);

        checkBox_IndexN = new QCheckBox(layoutWidget);
        checkBox_IndexN->setObjectName(QStringLiteral("checkBox_IndexN"));

        horizontalLayout_3->addWidget(checkBox_IndexN);


        verticalLayout_4->addLayout(horizontalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        checkBox_StartN = new QCheckBox(layoutWidget);
        checkBox_StartN->setObjectName(QStringLiteral("checkBox_StartN"));

        horizontalLayout_2->addWidget(checkBox_StartN);

        checkBox_StartP = new QCheckBox(layoutWidget);
        checkBox_StartP->setObjectName(QStringLiteral("checkBox_StartP"));

        horizontalLayout_2->addWidget(checkBox_StartP);


        verticalLayout_4->addLayout(horizontalLayout_2);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        checkBox_CaptchP = new QCheckBox(layoutWidget);
        checkBox_CaptchP->setObjectName(QStringLiteral("checkBox_CaptchP"));

        horizontalLayout_4->addWidget(checkBox_CaptchP);

        checkBox_CaptchN = new QCheckBox(layoutWidget);
        checkBox_CaptchN->setObjectName(QStringLiteral("checkBox_CaptchN"));

        horizontalLayout_4->addWidget(checkBox_CaptchN);


        verticalLayout_4->addLayout(horizontalLayout_4);

        comboBox_2 = new QComboBox(layoutWidget);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));

        verticalLayout_4->addWidget(comboBox_2);


        gridLayout_2->addLayout(verticalLayout_4, 2, 1, 1, 2);

        horizontalSpacer = new QSpacerItem(58, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 3, 2, 1, 1);

        gridLayout_5 = new QGridLayout();
        gridLayout_5->setSpacing(6);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        PushButtonInit = new QPushButton(layoutWidget);
        PushButtonInit->setObjectName(QStringLiteral("PushButtonInit"));

        gridLayout_5->addWidget(PushButtonInit, 0, 0, 1, 1);

        pushButton_9 = new QPushButton(layoutWidget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));

        gridLayout_5->addWidget(pushButton_9, 1, 0, 1, 1);

        pushButton_10 = new QPushButton(layoutWidget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));

        gridLayout_5->addWidget(pushButton_10, 2, 0, 1, 1);

        pushButton_Enable = new QPushButton(layoutWidget);
        pushButton_Enable->setObjectName(QStringLiteral("pushButton_Enable"));

        gridLayout_5->addWidget(pushButton_Enable, 3, 0, 1, 1);

        pushButton_12 = new QPushButton(layoutWidget);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));

        gridLayout_5->addWidget(pushButton_12, 4, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout_5, 3, 3, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label_pixMap = new QLabel(layoutWidget);
        label_pixMap->setObjectName(QStringLiteral("label_pixMap"));
        label_pixMap->setMinimumSize(QSize(200, 200));
        label_pixMap->setScaledContents(true);

        gridLayout->addWidget(label_pixMap, 0, 0, 1, 1);

        label_movie = new QLabel(layoutWidget);
        label_movie->setObjectName(QStringLiteral("label_movie"));

        gridLayout->addWidget(label_movie, 2, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 2, 4, 2, 1);

        groupBox = new QGroupBox(layoutWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout_10 = new QGridLayout(groupBox);
        gridLayout_10->setSpacing(6);
        gridLayout_10->setContentsMargins(11, 11, 11, 11);
        gridLayout_10->setObjectName(QStringLiteral("gridLayout_10"));
        gridLayout_8 = new QGridLayout();
        gridLayout_8->setSpacing(6);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        label_17 = new QLabel(groupBox);
        label_17->setObjectName(QStringLiteral("label_17"));

        gridLayout_8->addWidget(label_17, 0, 0, 1, 1);

        label_19 = new QLabel(groupBox);
        label_19->setObjectName(QStringLiteral("label_19"));

        gridLayout_8->addWidget(label_19, 1, 0, 1, 1);

        label_26 = new QLabel(groupBox);
        label_26->setObjectName(QStringLiteral("label_26"));

        gridLayout_8->addWidget(label_26, 2, 0, 1, 1);

        label_27 = new QLabel(groupBox);
        label_27->setObjectName(QStringLiteral("label_27"));

        gridLayout_8->addWidget(label_27, 3, 0, 1, 1);

        label_29 = new QLabel(groupBox);
        label_29->setObjectName(QStringLiteral("label_29"));

        gridLayout_8->addWidget(label_29, 4, 0, 1, 1);


        gridLayout_10->addLayout(gridLayout_8, 0, 0, 1, 1);

        gridLayout_9 = new QGridLayout();
        gridLayout_9->setSpacing(6);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        label_Sts = new QLabel(groupBox);
        label_Sts->setObjectName(QStringLiteral("label_Sts"));

        gridLayout_9->addWidget(label_Sts, 0, 0, 1, 1);

        label_Stage = new QLabel(groupBox);
        label_Stage->setObjectName(QStringLiteral("label_Stage"));

        gridLayout_9->addWidget(label_Stage, 1, 0, 1, 1);

        label_Error = new QLabel(groupBox);
        label_Error->setObjectName(QStringLiteral("label_Error"));

        gridLayout_9->addWidget(label_Error, 2, 0, 1, 1);

        label_23 = new QLabel(groupBox);
        label_23->setObjectName(QStringLiteral("label_23"));

        gridLayout_9->addWidget(label_23, 3, 0, 1, 1);

        label_28 = new QLabel(groupBox);
        label_28->setObjectName(QStringLiteral("label_28"));

        gridLayout_9->addWidget(label_28, 4, 0, 1, 1);


        gridLayout_10->addLayout(gridLayout_9, 0, 1, 1, 1);


        gridLayout_2->addWidget(groupBox, 2, 3, 1, 1);

        MyMainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MyMainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 981, 26));
        MyMainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MyMainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MyMainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MyMainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MyMainWindow->setStatusBar(statusBar);

        retranslateUi(MyMainWindow);

        QMetaObject::connectSlotsByName(MyMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MyMainWindow)
    {
        MyMainWindow->setWindowTitle(QApplication::translate("MyMainWindow", "MyMainWindow", 0));
        action_Reset->setText(QApplication::translate("MyMainWindow", "Reset", 0));
        label_16->setText(QApplication::translate("MyMainWindow", "TextLabel", 0));
        label_Url->setText(QApplication::translate("MyMainWindow", "TextLabel", 0));
        label->setText(QApplication::translate("MyMainWindow", "\350\275\264\345\217\267\357\274\232", 0));
        CBM_axis->clear();
        CBM_axis->insertItems(0, QStringList()
         << QApplication::translate("MyMainWindow", "1", 0)
         << QApplication::translate("MyMainWindow", "2", 0)
         << QApplication::translate("MyMainWindow", "3", 0)
         << QApplication::translate("MyMainWindow", "4", 0)
         << QApplication::translate("MyMainWindow", "5", 0)
         << QApplication::translate("MyMainWindow", "6", 0)
         << QApplication::translate("MyMainWindow", "7", 0)
         << QApplication::translate("MyMainWindow", "8", 0)
        );
        CBM_axis->setCurrentText(QApplication::translate("MyMainWindow", "1", 0));
        label_2->setText(QApplication::translate("MyMainWindow", "\345\233\236\351\233\266\346\250\241\345\274\217\350\256\276\347\275\256\357\274\232", 0));
        label_4->setText(QApplication::translate("MyMainWindow", "Index\346\220\234\347\264\242\346\226\271\345\220\221\357\274\232", 0));
        label_5->setText(QApplication::translate("MyMainWindow", "\346\215\225\350\216\267\350\247\246\345\217\221\346\262\277\357\274\232", 0));
        label_6->setText(QApplication::translate("MyMainWindow", "\346\215\225\350\216\267\350\247\246\345\217\221\345\231\250\357\274\232", 0));
        label_3->setText(QApplication::translate("MyMainWindow", "\345\233\236\351\233\266\345\220\257\345\212\250\346\226\271\345\220\221\357\274\232", 0));
        label_7->setText(QApplication::translate("MyMainWindow", "\346\220\234\347\264\242\351\200\237\345\272\246\357\274\232", 0));
        label_8->setText(QApplication::translate("MyMainWindow", "\345\256\232\344\275\215\351\200\237\345\272\246\357\274\232", 0));
        label_9->setText(QApplication::translate("MyMainWindow", "\345\212\240\351\200\237\345\272\246\357\274\232", 0));
        label_10->setText(QApplication::translate("MyMainWindow", "\345\207\217\351\200\237\345\272\246\357\274\232", 0));
        label_11->setText(QApplication::translate("MyMainWindow", "\345\271\263\346\273\221\346\227\266\351\227\264\357\274\232", 0));
        label_12->setText(QApplication::translate("MyMainWindow", "\351\233\266\347\202\271\345\201\217\347\275\256\357\274\232", 0));
        label_13->setText(QApplication::translate("MyMainWindow", "Home\346\220\234\347\264\242\350\267\235\347\246\273\357\274\232", 0));
        label_14->setText(QApplication::translate("MyMainWindow", "Index\346\220\234\347\264\242\350\267\235\347\246\273\357\274\232", 0));
        label_15->setText(QApplication::translate("MyMainWindow", "\345\217\215\345\220\221\350\204\261\347\246\273\346\255\245\351\225\277\357\274\232", 0));
        Edit_velHigh->setText(QApplication::translate("MyMainWindow", "100", 0));
        Edit_velLow->setText(QApplication::translate("MyMainWindow", "10", 0));
        Edit_acc->setText(QApplication::translate("MyMainWindow", "5", 0));
        Edit_dec->setText(QApplication::translate("MyMainWindow", "5", 0));
        Edit_smoothTime->setText(QApplication::translate("MyMainWindow", "10", 0));
        Edit_homeOffset->setText(QApplication::translate("MyMainWindow", "0", 0));
        Edit_searchHomeDistance->setText(QApplication::translate("MyMainWindow", "0", 0));
        Edit_searchIndexDistance->setText(QApplication::translate("MyMainWindow", "0", 0));
        Edit_escapeStep->setText(QApplication::translate("MyMainWindow", "1000", 0));
        comboBox_TRRIGER->clear();
        comboBox_TRRIGER->insertItems(0, QStringList()
         << QApplication::translate("MyMainWindow", "\351\273\230\350\256\244\350\256\276\347\275\256", 0)
         << QApplication::translate("MyMainWindow", "\350\247\246\345\217\221\345\231\250", 0)
        );
        checkBox_IndexP->setText(QApplication::translate("MyMainWindow", "\346\255\243\346\226\271\345\220\221", 0));
        checkBox_IndexN->setText(QApplication::translate("MyMainWindow", "\350\264\237\346\226\271\345\220\221", 0));
        checkBox_StartN->setText(QApplication::translate("MyMainWindow", "\350\264\237\346\226\271\345\220\221", 0));
        checkBox_StartP->setText(QApplication::translate("MyMainWindow", "\346\255\243\346\226\271\345\220\221", 0));
        checkBox_CaptchP->setText(QApplication::translate("MyMainWindow", "\346\255\243\346\226\271\345\220\221", 0));
        checkBox_CaptchN->setText(QApplication::translate("MyMainWindow", "\350\264\237\346\226\271\345\220\221", 0));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("MyMainWindow", "Home+Index\345\233\236\351\233\266", 0)
         << QApplication::translate("MyMainWindow", "Home\345\233\236\351\233\266", 0)
         << QApplication::translate("MyMainWindow", "Index\345\233\236\351\233\266", 0)
         << QApplication::translate("MyMainWindow", "\351\231\220\344\275\215+Home+Index\345\233\236\351\233\266", 0)
         << QApplication::translate("MyMainWindow", "\351\231\220\344\275\215+Home\345\233\236\351\233\266", 0)
         << QApplication::translate("MyMainWindow", "\351\231\220\344\275\215+Index\345\233\236\351\233\266", 0)
         << QApplication::translate("MyMainWindow", "\351\231\220\344\275\215\345\233\236\351\233\266", 0)
        );
        PushButtonInit->setText(QApplication::translate("MyMainWindow", "\345\210\235\345\247\213\345\214\226", 0));
        pushButton_9->setText(QApplication::translate("MyMainWindow", "\346\270\205\351\231\244\347\212\266\346\200\201", 0));
        pushButton_10->setText(QApplication::translate("MyMainWindow", "\345\220\257\345\212\250\350\277\220\345\212\250", 0));
        pushButton_Enable->setText(QApplication::translate("MyMainWindow", "\345\274\200\345\220\257\344\275\277\350\203\275", 0));
        pushButton_12->setText(QApplication::translate("MyMainWindow", "\345\201\234\346\255\242\345\233\236\351\233\266", 0));
        label_pixMap->setText(QApplication::translate("MyMainWindow", ".", 0));
        label_movie->setText(QApplication::translate("MyMainWindow", "TextLabel", 0));
        groupBox->setTitle(QApplication::translate("MyMainWindow", "\345\233\236\351\233\266\347\212\266\346\200\201", 0));
        label_17->setText(QApplication::translate("MyMainWindow", "\350\277\220\345\212\250\347\212\266\346\200\201\357\274\232", 0));
        label_19->setText(QApplication::translate("MyMainWindow", "\345\275\223\345\211\215\351\230\266\346\256\265\357\274\232", 0));
        label_26->setText(QApplication::translate("MyMainWindow", "\351\224\231\350\257\257\346\217\220\347\244\272\357\274\232", 0));
        label_27->setText(QApplication::translate("MyMainWindow", "\346\215\225\350\216\267\344\275\215\347\275\256\357\274\232", 0));
        label_29->setText(QApplication::translate("MyMainWindow", "\347\233\256\346\240\207\344\275\215\347\275\256\357\274\232", 0));
        label_Sts->setText(QApplication::translate("MyMainWindow", "run", 0));
        label_Stage->setText(QApplication::translate("MyMainWindow", "\351\235\231\346\200\201", 0));
        label_Error->setText(QApplication::translate("MyMainWindow", "\351\235\231\346\200\201", 0));
        label_23->setText(QApplication::translate("MyMainWindow", "\351\235\231\346\200\201", 0));
        label_28->setText(QApplication::translate("MyMainWindow", "\351\235\231\346\200\201", 0));
    } // retranslateUi

};

namespace Ui {
    class MyMainWindow: public Ui_MyMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYMAINWINDOW_H
